package pdsu.edu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pdsu.edu.bean.Student;
import pdsu.edu.util.DBUtil;

public class StudentDao {
  //1.����Student�Ĳ���
   public boolean  insert(Student stu) {
	   Connection conn =null;
	   PreparedStatement pt=null;
	   String sql="insert into student values(?,?,?,?,?)";
	   try {
	    conn = DBUtil.getConnection();
		pt = conn.prepareStatement(sql);
		pt.setObject(1, stu.getSno());
		pt.setObject(2, stu.getSname());
		pt.setObject(3,stu.getSex());
		pt.setObject(4, stu.getAge());
		pt.setObject(5, stu.getSclass());
		int num = pt.executeUpdate();
		if(num>0) {
			//System.out.println("���ӳɹ���");
			return true;
		}
		return false;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		DBUtil.close(null, pt, conn);
	}	
	return false;
	   
   }
  //2.��ѯ����ѧ��Student����Ĳ���
   public List<Student> findAll(){
	   Connection conn =null;
	   PreparedStatement pt =null;
	   ResultSet rs =null;
	   String sql="select * from student";	
	   ArrayList<Student> list = new ArrayList<Student>();
	   try {
		   conn = DBUtil.getConnection();
		   pt=conn.prepareStatement(sql);
		   rs= pt.executeQuery();
		   while(rs.next()) {
			   Student stu=new Student();
			   stu.setSno(rs.getString("sno"));
			   stu.setSname(rs.getString("sname"));
			   stu.setSex(rs.getString("sex"));
			   stu.setAge(rs.getInt("age"));
			   stu.setSclass(rs.getInt("sclass"));
			   list.add(stu);
		   }
		   return list;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		DBUtil.close(rs, pt, conn);
	}
	return null;
	   
   }
  //3.����ѧ�Ų�ѯ�ķ���
   public Student find(String sno) {
	   Connection conn =null;
	   PreparedStatement pt =null;
	   ResultSet rs =null;
	   String sql="select * from student where sno=?";		   
	   try {
		   conn = DBUtil.getConnection();
		   pt=conn.prepareStatement(sql);
		   pt.setObject(1, sno);
		   rs= pt.executeQuery();
		   while(rs.next()) {			   
			   Student stu = new Student();
			   stu.setSno(rs.getString("sno"));
			   stu.setSname(rs.getString("sname"));
			   stu.setSex(rs.getString("sex"));
			   stu.setAge(rs.getInt("age"));
			   stu.setSclass(rs.getInt("sclass"));		  
			   return stu;
		   }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		DBUtil.close(rs, pt, conn);
	}
	return null;
	   
   }
  //4.����ѧ������������ݿ�ķ���
   public boolean update(Student stu) {
	   Connection conn =null;
	   PreparedStatement pt =null;
	   ResultSet rs =null;
	   String sql="update student set sname=?,sex=?,age=?,sclass=? where sno=?";		   
	   try {
		   conn = DBUtil.getConnection();
		   pt=conn.prepareStatement(sql);
		   pt.setObject(1,stu.getSname());
		   pt.setObject(2, stu.getSex());
		   pt.setObject(3,stu.getAge());
		   pt.setObject(4, stu.getSclass());
		   pt.setObject(5, stu.getSno());
		   int num = pt.executeUpdate();
		   if(num>0) {
			   return true;
		   }
		   return false;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		DBUtil.close(rs, pt, conn);
	}
	return false;
	   
   }
  //5.����ѧ��ѧ��ɾ��ѧ����Ϣ�ķ���
   public boolean delete(String sno) {
	   Connection conn =null;
	   PreparedStatement pt =null;
	   ResultSet rs =null;
	   String sql="delete from student where sno=?";		   
	   try {
		   conn = DBUtil.getConnection();
		   pt=conn.prepareStatement(sql);
		   pt.setObject(1, sno);
		   int num = pt.executeUpdate();
		   if(num>0) {
			   return true;
		   }
		   return false;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		DBUtil.close(rs, pt, conn);
	}
	return false;
	   
   }
}
