package pdsu.edu.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import pdsu.edu.util.DBUtil;

public class TestScoll {

	public static void main(String[] args) {
      Connection conn=null;
      Statement st =null;
      ResultSet rs =null;
      try {
    	conn = DBUtil.getConnection();
		//st = conn.createStatement();
    	//�����ɹ��������
		//st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
    	//�����ɸ��½����
    	st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		String sql="select * from student";
		rs = st.executeQuery(sql);
		/*while(rs.next()) {
			System.out.print("sno:"+rs.getString(1)+"\t");
			System.out.print("sname:"+rs.getString(2)+"\t");
			System.out.print("sex:"+rs.getString(3)+"\t");
			System.out.print("age:"+rs.getInt(4)+"\t");
			System.out.print("sclass:"+rs.getInt(5)+"\t");
			System.out.println();
		}*/
		// ���Կɹ��������
		//rs.next();
		//System.out.println(rs.getString(1));
		//rs.last();
//		rs.absolute(3);
//		System.out.println(rs.getString(1));
//		System.out.println(rs.getRow());
//		System.out.println(rs.isLast());
		//���Կɸ��½����
//		rs.next();
//		rs.updateString(2, "����");
//		rs.updateRow();
		//����һ������
		/*rs.moveToInsertRow();
		rs.updateString(1, "0000");
		rs.updateString(2, "9999");
		rs.updateString(3, "��");
		rs.updateInt(4, 20);
		rs.updateInt(5, 3);
		rs.insertRow();*/
		rs.moveToCurrentRow();
		rs.absolute(1);
		rs.deleteRow();
		
	} catch (SQLException e) {
		e.printStackTrace();
	}finally {
		DBUtil.close(rs, st, conn);
	}
		
	}

}
