package Util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;



public class DBUtil {

	private static String driverClass;
	private static String url;
	private static String userName;
	private static String password;
	  static {
		  Properties p = new Properties();
		  try {
			FileInputStream is = new FileInputStream(new File("src/db.properties"));
			try {
				p.load(is);
				driverClass=p.getProperty("driver");
				url=p.getProperty("url");
				userName=p.getProperty("user");
				password=p.getProperty("pwd");
				try {
					Class.forName(driverClass);
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}	
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	  }
	  public static Connection getConnection() {
		 Connection conn=null;
		  try {
			conn=DriverManager.getConnection(url,userName,password);			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	  }	  
	  public static void close(ResultSet rs,Statement st,Connection conn) {
		    try {
				 if(rs!=null) {
				  rs.close();				 
			}
				 if(st!=null) {
				    	st.close();
				    }
				 if(conn!=null) {
					 conn.close();
				 }
		    }
		    catch (SQLException e) {
				e.printStackTrace();
			}
		  
	  }
	  public static void main(String[] args) {
		Connection conn=DBUtil.getConnection();
		System.out.println(conn);
		DBUtil.close(null,null, conn);
		
	}
}

