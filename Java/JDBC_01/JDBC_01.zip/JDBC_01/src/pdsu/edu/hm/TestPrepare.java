package pdsu.edu.hm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Util.DBUtil;

public class TestPrepare {

	public static void main(String[] args) {
        Connection conn =null;
		PreparedStatement pt =null;
		ResultSet rs =null;	
		try {
			conn=DBUtil.getConnection();
			//String sql="insert into student values(?,?,?,?,?)";
			//String sql="update student set age=? where sname=?";
			String sql="select * from student where age=?";
			pt = conn.prepareStatement(sql);
			pt.setObject(1, 20);
			rs = pt.executeQuery();
			 while(rs.next()) {					
					System.out.print("ѧ�ţ�"+rs.getString("sno")+"\t");
					System.out.print("������"+rs.getString("sname")+"\t");
					System.out.print("�Ա�"+rs.getString("sex")+"\t");
					System.out.print("���䣺"+rs.getInt("age")+"\t");
					System.out.print("�༶��"+rs.getInt("sclass")+"\t");
					System.out.println();
				}
			/*pt.setObject(1, "9999");
			pt.setObject(2, "�");
			pt.setObject(3, "��");
			pt.setObject(4, 30);
			pt.setObject(5, 10);*/
			/*pt.setObject(1, 40);
			pt.setObject(2, "�");
			int n = pt.executeUpdate();
			System.out.println("������"+n+"��");*/
			DBUtil.close(rs,pt, conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
