package pdsu.edu.hm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Util.DBUtil;

public class TestUtil {

	public static void main(String[] args) {

		Connection conn =null;
		Statement st =null;
		ResultSet rs =null;
		try {
			 conn=DBUtil.getConnection();
		     st = conn.createStatement();
			 String sql="select * from student";
			 rs=st.executeQuery(sql);
			 while(rs.next()) {
					/*System.out.print("ѧ�ţ�"+rs.getString(1)+"\t");
					System.out.print("������"+rs.getString(2)+"\t");
					System.out.print("�Ա�"+rs.getString(3)+"\t");
					System.out.print("���䣺"+rs.getInt(4)+"\t");
					System.out.print("�༶��"+rs.getInt(5)+"\t");*/
					System.out.print("ѧ�ţ�"+rs.getString("sno")+"\t");
					System.out.print("������"+rs.getString("sname")+"\t");
					System.out.print("�Ա�"+rs.getString("sex")+"\t");
					System.out.print("���䣺"+rs.getInt("age")+"\t");
					System.out.print("�༶��"+rs.getInt("sclass")+"\t");
					System.out.println();
				}
			DBUtil.close(rs, st, conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
