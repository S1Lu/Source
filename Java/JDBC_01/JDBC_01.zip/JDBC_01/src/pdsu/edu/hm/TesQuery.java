package pdsu.edu.hm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TesQuery {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/school?useUnicode=true&characterEncoding=UTF-8";
		String userName = "root";
		String password = "root";
		Connection conn =null;
		Statement st =null;
		ResultSet rs =null;
		try {
			Class.forName("com.mysql.jdbc.Driver");			
			conn = DriverManager.getConnection(url,userName,password);
			st = conn.createStatement();
			String sql="select * from student";
			rs = st.executeQuery(sql);
			while(rs.next()) {
				/*System.out.print("ѧ�ţ�"+rs.getString(1)+"\t");
				System.out.print("������"+rs.getString(2)+"\t");
				System.out.print("�Ա�"+rs.getString(3)+"\t");
				System.out.print("���䣺"+rs.getInt(4)+"\t");
				System.out.print("�༶��"+rs.getInt(5)+"\t");*/
				System.out.print("ѧ�ţ�"+rs.getString("sno")+"\t");
				System.out.print("������"+rs.getString("sname")+"\t");
				System.out.print("�Ա�"+rs.getString("sex")+"\t");
				System.out.print("���䣺"+rs.getInt("age")+"\t");
				System.out.print("�༶��"+rs.getInt("sclass")+"\t");
				System.out.println();
			}
			
		  } catch (ClassNotFoundException e) {
		   System.out.println("��������ʧ�ܣ�");
		  } catch (SQLException e) {
			System.out.println("��������ʧ�ܣ�");
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(st!=null) {
				try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
