//Product.java
package shoppingcart;

public class Product {
	private String id;// ��Ʒ��ʶ
	private String name;// ��Ʒ����
	private String description;// ��Ʒ����
	private double price;// ��Ʒ�۸�
	private int num;// ��Ʒ����

	public Product() {
	}

	public Product(String id, String name, String description, double price, int num) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.num = num;
	}

	public String getId() {
		return (this.id);
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return (this.name);
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return (this.description);
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return (this.price);
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getNum() {
		return (this.num);
	}

	public void setNum(int num) {
		this.num = num;
	}
}
