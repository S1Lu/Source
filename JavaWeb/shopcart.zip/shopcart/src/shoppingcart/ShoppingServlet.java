//ShoppingServlet.java
package shoppingcart;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ShoppingServlet extends HttpServlet {
	private static final String CONTENT_TYPE = "text/html;charset=GBK";

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType(CONTENT_TYPE);
		ServletContext context = getServletContext();
		HttpSession session = request.getSession();
		ShopCart cart = (ShopCart) session.getAttribute("shopCart");
		String action = request.getParameter("action");
		if ("remove".equals(action)) { // �ӹ��ﳵ������һ����Ʒ
			String removeId = request.getParameter("removeId");
			cart.removeProductFromCart(removeId);
		} else if ("add".equals(action)) {
			String[] productIds = request.getParameterValues("productId");// ��ȡ��ǰ�û�ѡ��Ĳ�ƷID
			Map products = (Map) context.getAttribute("products"); // ��ServletContext��������ȡ��Ʒ��Ϣ
			if (cart == null) {
				cart = new ShopCart(); // ����һ�����ﳵ����
				session.setAttribute("shopCart", cart);
			}
			if (productIds == null) {
				productIds = new String[0];
			}
			for (int i = 0; i < productIds.length; i++) { // ���û�ѡ��Ĳ�Ʒ���ӵ����ﳵ��
				Product product = (Product) products.get(productIds[i]);
				cart.addProductToCart(product);
			}
		}
		RequestDispatcher rd = request.getRequestDispatcher("/showcart");
		rd.forward(request, response); // ת���ﳵ��ʾ��Servlet
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
