//ShopCart.java
package shoppingcart;

import java.util.*;

public class ShopCart {
	private ArrayList<Product> cart = null;// List���󣬴����Ʒ

	public ShopCart() {
		cart = new ArrayList<Product>();
	}

	public void addProductToCart(Product product) { // ���ﳵ��������Ʒ
		boolean is = false;
		for (int i = 0; i < cart.size(); i++) {
			if (cart.get(i).getId().equals(product.getId())) {
				is = true;
				cart.get(i).setNum(cart.get(i).getNum() - 1);
				break;
			}
		}
		if (is == false) {
			product.setNum(99);
			cart.add(product);
		}
	}

	public void removeProductFromCart(String productId) { // �ӹ��ﳵ��ɾ��һ��Ʒ
		if (cart == null)
			return;
		Iterator it = cart.iterator();
		while (it.hasNext()) {
			Product item = (Product) it.next();
			if (item.getId().equals(productId)) {
				it.remove();
				item.setNum(100);
				return;
			}
		}
	}

	public double getAllProductPrice() { // ���㹺�ﳵ�е���Ʒ�۸�
		if (cart == null)
			return 0;
		double totalPrice = 0;
		Iterator it = cart.iterator();
		while (it.hasNext()) {
			Product item = (Product) it.next();
			totalPrice += item.getPrice() * (100 - item.getNum());
		}
		return totalPrice;
	}

	public List getAllProductsFromCart() { // ���ع��ﳵ���в�Ʒ��Ϣ
		return cart;
	}
}
