package s1.lu.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Test1
 */
@WebServlet("/Test1")
public class Test1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Test1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//������Ӧ���ַ����������
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("����ķ���Ϊ:"+request.getMethod()+"<br>");
		out.println("�����URIΪ:"+request.getRequestURI()+"<br>");
		out.println("�����URLΪ:"+request.getRequestURL()+"<br>");
		out.println("����Ĳ�ѯ����Ϊ:"+request.getQueryString()+"<br>");
		out.println("�����Э��Ϊ:"+request.getProtocol()+"<br>");
		out.println("�����������Ϊ:"+request.getContextPath()+"<br>");
		out.println("�����servlet��ӳ��·��Ϊ:"+request.getServletPath()+"<br>");
		
		
		Enumeration<String> enumeration = request.getHeaderNames();
		out.print("<table border=1>");
		 while (enumeration .hasMoreElements() ) {
		    String headerName = enumeration .nextElement() ;
		    String headerValue = request.getHeader(headerName);     
		    out.print("<tr>");
		    out.print("<td>"+headerName + "</td>");
		    out.println("<td>"+headerValue + "</td>");
		    out.print("</tr>");
		    }
		 out.print("</table>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
