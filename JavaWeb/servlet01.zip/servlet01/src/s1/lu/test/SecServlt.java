package s1.lu.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class SecServlt extends GenericServlet {
	/*
	 * �̳�GenericServlet
	 * */
	
	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		// TODO Auto-generated method stub
		arg1.setContentType("text/html;charset=utf-8");
		PrintWriter out = arg1.getWriter();
		out.printf("b");
		out.close();

	}

}
