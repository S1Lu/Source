package s1.lu.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Util.DBUtil;

public class Util {

	public static void main(String[] args) {

		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;

		try {
			connection = DBUtil.getConnection();
			statement = connection.createStatement();
			String sql = "select * from student";
			rs = statement.executeQuery(sql);
			while (rs.next()) {
				/*
				 * Sys tem.out.print("ѧ�ţ�"+rs.getString(1)+"\t");
				 * System.out.print("������"+rs.getString(2)+"\t");
				 * System.out.print("�Ա�"+rs.getString(3)+"\t");
				 * System.out.print("���䣺"+rs.getInt(4)+"\t");
				 * System.out.print("�༶��"+rs.getInt(5)+"\t");
				 */
				System.out.print("ѧ�ţ�" + rs.getString("sno") + "\t");
				System.out.print("������" + rs.getString("sname") + "\t");
				System.out.print("�Ա�" + rs.getString("sex") + "\t");
				System.out.print("���䣺" + rs.getInt("age") + "\t");
				System.out.print("�༶��" + rs.getInt("sclass") + "\t");
				System.out.println();
			}
		} catch (SQLException e) {
			System.out.println("��������ʧ�ܣ�");
		}finally {
			DBUtil.close(rs, statement, connection);
		}
	}

}
