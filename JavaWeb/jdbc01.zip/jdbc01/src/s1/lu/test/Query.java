package s1.lu.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Query {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/school?useUnicode=true&characterEncoding=UTF-8";
		// ?useUnicode=true&characterEncoding=UTF-8"; ��Ϊ�˽����Ӧ�ó��������ݿ�д������ʱ�������������
		String userName = "root";
		String password = "root";
		Connection connection=null;
		Statement statement=null;
		ResultSet rs=null;
		
		
	try {
		Class.forName("com.mysql.jdbc.Driver");
		
		connection= DriverManager.getConnection(url,userName,password);
		
		 statement = connection.createStatement();
		
		String sql="select * from student";
		
		 rs = statement.executeQuery(sql);
		
		while (rs.next()) {
			System.out.print("ѧ�ţ�" + rs.getString("sno") + "\t");
			System.out.print("������" + rs.getString("sname") + "\t");
			System.out.print("�Ա�" + rs.getString("sex") + "\t");
			System.out.print("���䣺" + rs.getInt("age") + "\t");
			System.out.print("�༶��" + rs.getInt("sclass") + "\t");
			System.out.println();
			
		}
		
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		if (rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (statement!=null) {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (connection!=null) {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	}
	

}
