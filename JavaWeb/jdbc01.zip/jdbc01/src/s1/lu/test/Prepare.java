package s1.lu.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Util.DBUtil;

public class Prepare {

	public static void main(String[] args) {
		Connection connection = null;
		PreparedStatement pt = null;

		try {
			connection = DBUtil.getConnection();

			String sql = "insert into student values(?,?,?,?,?)";

			// sql="select * from student where age=?"
			pt = connection.prepareStatement(sql);

//			pt.setObject(1, 20);
//			
//			ResultSet rs = pt.executeQuery();
//			while(rs.next()) {					
//				System.out.print("ѧ�ţ�"+rs.getString("sno")+"\t");
//				System.out.print("������"+rs.getString("sname")+"\t");
//				System.out.print("�Ա�"+rs.getString("sex")+"\t");
//				System.out.print("���䣺"+rs.getInt("age")+"\t");
//				System.out.print("�༶��"+rs.getInt("sclass")+"\t");
//				System.out.println();
//			}

			pt.setObject(1, "44449");
			pt.setObject(2, "�");
			pt.setObject(3, "��");
			pt.setObject(4, 30);
			pt.setObject(5, 10);

			int n = pt.executeUpdate();
			System.out.println("������" + n + "��");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// ���µĹر���ԴDBUtil.close(rs,pt,connection);
			DBUtil.close(null, pt, connection);
		}
	}

}
