package s1.lu.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/WelcomeBack")
public class WelcomeBack extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String user = request.getParameter("username");

		if (user == null || user.equals("")) { // Find the "username" cookie
			Cookie[] cookies = request.getCookies();
			for (int i = 0; cookies != null && i < cookies.length; ++i) {
				if (cookies[i].getName().equals("username"))
					user = cookies[i].getValue();
			}
		} else {
			System.out.println("user not null");
			response.addCookie(new Cookie("username", user));
		}

		if (user == null || user.equals("")) // No parameter and no cookie
			response.sendRedirect("getname.html");
		else {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html><body><h1>Welcome Back " + user + "</h1></body></html>");
		}
	}
}
