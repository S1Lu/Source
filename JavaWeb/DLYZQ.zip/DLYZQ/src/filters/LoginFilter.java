﻿package filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginFilter implements Filter {
	private String logon_page;//登录页面
	private String logon_servlet;//登录servlet请求
	//消毁filter方法
	public void destroy() {
	}
	//过滤器服务方法
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		resp.setContentType("text/html;");
		resp.setCharacterEncoding("utf-8");
		HttpSession session = req.getSession();
		PrintWriter out = resp.getWriter();
		// 得到用户请求的URI
		String request_uri = req.getRequestURI();
		// 得到web应用程序的上下文路径
		String ctxPath = req.getContextPath();
		// 去除上下文路径，得到剩余部分的路径
		String uri = request_uri.substring(ctxPath.length());
		// 判断用户访问的是否是登录页面或提交登录请求
		if (uri.equals(logon_page)||uri.equals(logon_servlet)) {
			//执行下一个过滤器
			chain.doFilter(request, response);
		} else {
			// 如果访问的不是登录页面，则判断用户是否已经登录
			if (null != session.getAttribute("user")
					&& "" != session.getAttribute("user")) {
				//执行下一个过滤器
				chain.doFilter(request, response);
			} else {
				out.println("您没有登录，请先登录！3秒钟后回到登录页面。");
				resp.setHeader("refresh", "3;url=" + ctxPath + logon_page);
				return;
			}
		}
	}
	//过滤器初始化方法
	public void init(FilterConfig config) throws ServletException {
		// 从web.xml的部署描述符中获取登录页面
		logon_page = config.getInitParameter("login_uri");
		logon_servlet = config.getInitParameter("login_Servlet");
	}

}
