package s1.lu.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import s1.lu.bean.Student;
import s1.lu.util.DBUtil;

/*dao��
Data Access Object ���ݷ��ʶ���
DAO���ڷ�װ���ݿ���ʲ�����һ�����ģʽ��
DAO:��������Ľӿڣ����綨�����ݿ��ԭ���Բ�������ɾ�Ĳ�����ȡ�
*/

public class StudentDao {
	  //1.����Student�Ĳ���
	public boolean insert(Student stu) {	
		Connection connection=null;
		PreparedStatement pt=null;
		try {
			connection = DBUtil.getConnection();
			String sql="insert into student values(?,?,?,?,?)";
			pt = connection.prepareStatement(sql);
			pt.setObject(1, stu.getSno());
			pt.setObject(2, stu.getSname());
			pt.setObject(3,stu.getSex());
			pt.setObject(4, stu.getAge());
			pt.setObject(5, stu.getSclass());
			int n=pt.executeUpdate();
			if(n>0) {
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(null, pt, connection);
		}
		return false;
	}
	
	
	//2.��ѯ����ѧ��Student����Ĳ���
	public List<Student> findAll(){
		Connection connection=null;
		PreparedStatement pt=null;
		ResultSet rs =null;
		ArrayList<Student> list=new ArrayList<Student>();
		String sql="select * from student";
		try {
			connection=DBUtil.getConnection();
			pt=connection.prepareStatement(sql);
			rs=pt.executeQuery();
			
			while (rs.next()) {
				Student student = new Student();
				student.setSno(rs.getString("sno"));
				student.setSname(rs.getString("sname"));
				student.setSex(rs.getString("sex"));
				student.setAge(rs.getInt("age"));
				student.setSclass(rs.getInt("sclass"));
				list.add(student);
			}
			return list;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(rs, pt, connection);
		}
		return null;
	}
	
}
