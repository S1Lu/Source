package s1.lu.test;

import java.util.Iterator;
import java.util.List;

import s1.lu.bean.Student;
import s1.lu.dao.StudentDao;

public class TestDao {

	public static void main(String[] args) {

		// 1.����һ��student
//		StudentDao dao=new StudentDao();
//		Student stu=new Student();
//		stu.setSno("6666");
//		stu.setSname("˹��˹");
//		stu.setSex("��");
//		stu.setAge(20);
//		stu.setSclass(1);
//		boolean b = dao.insert(stu);
//		if(b) {
//			System.out.println("���ӳɹ�");
//		}else {
//			System.out.println("����ʧ��");
//		}

		// 2.��ѯ����ѧ��
		StudentDao dao = new StudentDao();
		List<Student> list = dao.findAll();
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Student student = (Student) iterator.next();
			System.out.print("ѧ�ţ�"+student.getSno()+ "\t");
			System.out.print("������"+student.getSname()+ "\t");
			System.out.print("�Ա�"+student.getSex()+ "\t");
			System.out.print("���䣺"+student.getAge()+ "\t");
			System.out.print("�༶��"+student.getSclass()+ "\t");
			System.out.println();
		}
	}

}
